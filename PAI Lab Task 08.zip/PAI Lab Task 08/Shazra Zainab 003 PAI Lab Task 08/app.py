
from flask import Flask, render_template, request, redirect, url_for
import csv
import os

app = Flask(__name__)
CSV_FILE = 'StudentDetails.csv'

def read_students():
    students = []
    if os.path.exists(CSV_FILE):
        with open(CSV_FILE, mode='r', newline='') as file:
            reader = csv.DictReader(file)
            students = list(reader)
    return students

def write_student(data):
    file_exists = os.path.isfile(CSV_FILE)
    with open(CSV_FILE, mode='a', newline='') as file:
        fieldnames = ['Name', 'Roll No', 'Department']
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        if not file_exists or os.stat(CSV_FILE).st_size == 0:
            writer.writeheader()
        writer.writerow(data)

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        name = request.form['name']
        roll_no = request.form['roll_no']
        dept = request.form['department']
        write_student({'Name': name, 'Roll No': roll_no, 'Department': dept})
        return redirect(url_for('index'))

    search_query = request.args.get('search', '').lower()
    students = read_students()
    if search_query:
        students = [s for s in students if search_query in s['Name'].lower() or search_query in s['Roll No'].lower()]
    return render_template('index.html', students=students, search_query=search_query)

if __name__ == '__main__':
    app.run(debug=True)
